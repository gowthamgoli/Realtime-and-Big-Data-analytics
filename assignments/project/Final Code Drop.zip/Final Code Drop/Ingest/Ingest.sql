hdfs dfs -put OATH_ECB_Hearings_Case_Status.csv  project

hdfs dfs -put Water_Quality_complaints.csv  project

hdfs dfs -put Air_Quality.csv  project

hdfs dfs -put 311_Service_Requests_from_2010_to_Present.csv  project